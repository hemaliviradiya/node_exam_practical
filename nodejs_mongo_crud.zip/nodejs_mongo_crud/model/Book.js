const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({

    title: {
        type: String
    },
    author: {
        type: String
    },
    price: {
        type: Number
    }
});

module.exports = mongoose.model('Book',BookSchema)