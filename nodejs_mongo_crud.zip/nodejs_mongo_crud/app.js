const express = require('express');
const mongoose = require('mongoose');
const app = express();

mongoose.connect('mongodb://localhost:27017/BookDBex')
const db = mongoose.connection

db.on('open', ()=>{
    console.log('Connected to database..!!')
})

app.set('view engine','ejs')


app.use(express.json())

app.use(express.urlencoded({extended: true}))

app.use(express.static('public'))

const Bookroutes = require('./router/BookRouter')
app.use('/books', Bookroutes)

app.listen(8080, ()=>{
    console.log('Server listing on 8080')
});