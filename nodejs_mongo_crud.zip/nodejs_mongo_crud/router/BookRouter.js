const express = require('express');
const router = express.Router();
const Book = require('../model/Book')

router.get('/', async (req, res) => {
    try {
        const bk = await Book.find()
        res.render('pages/index', {
            bk: bk
        })
        // res.json(bk)
    } catch (error) {
        res.send('Error' + error)
    }
});

router.post('/add', async(req,res)=>{
    
    const bk = new Book({
        title: req.body.title,
        author: req.body.author,
        price: req.body.price
    })

    try {
        const badd = await bk.save()
        res.setHeader('Content-Type','Application/json')
        // res.json(badd)
        res.redirect('/books')
    } catch (error) {
        res.send('Error' + error)
    }
});

router.get('/:id', async (req, res) => {
    try {
        const bk = await Book.findById(req.params.id)
        res.render('pages/up', {
            bk: bk
        })
        // res.json(bk)
    } catch (error) {
        res.send('Error' + error)
    }
});

router.post('/up/:id', async (req, res) => {
    try {
        const bk = await Book.findById(req.params.id)
        bk.title = req.body.title,
        bk.author = req.body.author,
        bk.price = req.body.price
        await bk.save()
        res.redirect('/books')
        // res.json(upbk)
    } catch (error) {
        res.send('Error' + error)
    }
});

router.get('/dl/:id', async (req, res) => {
    try {
        const bk = await Book.findById(req.params.id)
        await bk.deleteOne(bk)
        res.redirect('/books')
    } catch (error) {
        res.send('Error' + error)
    }
});

module.exports = router

