var express = require('express');
var path = require('path');
const mongoose = require('mongoose');

var indexRouter = require('./routes/index');

var app = express();

// db connection
mongoose.connect('mongodb+srv://hemaliviradiya:hemali@cluster0.l87whji.mongodb.net/Stud')
  .then(() => console.log('DB Connected!'))
  .catch((err)=>{
    console.log(err.message);
  });

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);

module.exports = app;
