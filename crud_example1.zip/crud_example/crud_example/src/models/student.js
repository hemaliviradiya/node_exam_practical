const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const StudentSchema = new Schema({
    fname: String,
    lname: String,
    std: Number,
    roll_no: Number,
    address: String
});

const STUDENT = mongoose.model('student', StudentSchema);
module.exports = STUDENT;

