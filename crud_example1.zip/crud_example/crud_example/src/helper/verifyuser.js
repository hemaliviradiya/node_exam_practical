const USER = require('../models/user');
const jwt = require('jsonwebtoken');

let Secure = async (req, res, next) => {
    try {
        console.log('req.headers=>',req.headers);
        let token = req.headers.token;
        let decoded = jwt.verify(token, 'mytokensecretkey');
        let Checkuser = await USER.findById(decoded.id);
        if (!Checkuser) {
            throw new Error("User Not Found");
        }
        next();
    } catch (error) {
        res.status(404).json({
            status: "Fail",
            message: error.message
        });
    }
}

module.exports = {
    Secure
}