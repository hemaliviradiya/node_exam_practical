const express = require('express');
const userController = require('../conrollers/user');
const studentController = require('../conrollers/student');
const router = express.Router();
const upload = require('../helper/storagedisk');
const verifyUser = require('../helper/verifyuser');

router.post('/register/signup', upload.single('userimage'), userController.Signup);
router.post('/signin', userController.Signin);

router.get('/abc', function(req, res, next) {
  res.render('login');
});

router.get('/student', function(req, res, next) {
  res.render('student');
});

router.use(verifyUser.Secure);

router.post('/add', studentController.addStudent);

router.get('/show', studentController.showStudent);

router.post('/edit', studentController.editStudent);

router.get('/delete', studentController.deleteStudent);



module.exports = router;
