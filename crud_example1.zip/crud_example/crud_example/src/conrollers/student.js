
var STUDENT = require('../models/student');

let addStudent = async (req, res) => {
    try {
        console.log(req.body);
        let data = await STUDENT.create(req.body)
        res.status(201).json({
            status: "Success",
            message: "Add Data Successfully...",
            data: data
        });
    } catch (error) {
        res.status(404).json({
            status: "Fail",
            message: error.message
        });
    }
}

let showStudent = async (req, res) => {
    try {
        let data = await STUDENT.find();
        res.status(200).json({
            status: "Success",
            message: "Show Data Successfully...",
            data: data
        });
    } catch (error) {
        res.status(404).json({
            status: "Fail",
            message: error.message
        });
    }
}

let editStudent = async (req, res) => {
    try {
        let eid = req.query.eid;
        let data = await STUDENT.findByIdAndUpdate(eid, req.body);
        console.log("edited");
        res.status(200).json({
            status: "Success",
            message: "Edit Data Successfully...",
            data: data
        });
    } catch (error) {
        res.status(404).json({
            status: "Fail",
            message: error.message
        });
    }
}

let deleteStudent = async (req, res) => {
    try {
        let did = req.query.did;
        let data = await STUDENT.findByIdAndDelete(did);
        res.status(200).json({
            status: "Success",
            message: "Delete Data Successfully...",
            data: data
        });
    } catch (error) {
        res.status(404).json({
            status: "Fail",
            message: error.message
        });
    }
}

module.exports = {
    addStudent,
    showStudent,
    editStudent,
    deleteStudent
}