const app = require('./src/app');
const http = require('http');
const port = 3000;

http.createServer(app).listen(port, () => {
    console.log(`Server Connect Port : ${port}`)
});