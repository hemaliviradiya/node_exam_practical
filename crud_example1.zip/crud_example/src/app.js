const express = require('express');
const app = express();
const bodyparser = require('body-parser')
const Routers = require('./routes/index')
const mongoose = require('mongoose');

app.use(bodyparser.json())
app.use(bodyparser.urlencoded({ extended: false }))

mongoose.connect('mongodb+srv://hemaliviradiya:hemali@cluster0.l87whji.mongodb.net/demo')
    .then(() => console.log(' DB Connected!'))
    .catch((err) => {
        console.log(err.message);
    });

app.use('/', Routers)

module.exports = app;