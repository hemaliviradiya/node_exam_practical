const express = require('express');
const router = express.Router()
const controller = require('../controllers/index')

router.post("/sign-up", controller.SignUp);

module.exports = router;