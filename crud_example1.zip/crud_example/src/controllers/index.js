const USER = require('../model/user')

let SignUp = async (req, res) => {
  let reqData = req.body;
  try {
    if (reqData.fname != '' && reqData.lname != '' && reqData.email != '' && reqData.contact != '' && reqData.password != '' && reqData.cpassword != '') {
      let data = await USER.create(req.body);
      res.status(201).json({
        status: "Success",
        message: "Create Account Successfully...",
        data: data
      })
    } else {
      throw new Error('please enter valid data')
    }
  } catch (error) {
    res.status(404).json({
      status: "Fail",
      message: error.message
    })
  }
};

module.exports = {
  SignUp,
};
