const express = require('express');
const ejs = require('ejs');
const router = express.Router();

// router.get('/', (req, res) =>{
//     //res.send("Home Page");
//     res.render('index',{ title: "Home Page" });
// });

app.get('/', (req, res) => {
    // Data to be passed to the template
    const data = {
        title: 'Sample EJS Template',
        name: 'John Doe',
    };

    // Render the template and send it as a response
    res.render('index.ejs', data);
});

module.exports = router;